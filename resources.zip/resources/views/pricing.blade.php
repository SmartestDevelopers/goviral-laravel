@extends('layouts.front')

@section('content')

<h1>Pricing</h1>

@endsection
