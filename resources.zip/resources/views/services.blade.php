@extends('layouts.front')

@section('content')

<h1>Services</h1>

@endsection
