@extends('layouts.front')

@section('content')

<h1>BLOG</h1>

@endsection
