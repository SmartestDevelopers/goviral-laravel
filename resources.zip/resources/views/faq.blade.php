@extends('layouts.front')

@section('content')

<h1>FAQ</h1>

@endsection
