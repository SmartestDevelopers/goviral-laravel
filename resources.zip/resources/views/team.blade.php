@extends('layouts.front')

@section('content')

<h1>Team</h1>

@endsection
