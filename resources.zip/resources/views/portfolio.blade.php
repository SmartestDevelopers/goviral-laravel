@extends('layouts.front')

@section('content')

<h1>PORTFOLIO</h1>

@endsection
