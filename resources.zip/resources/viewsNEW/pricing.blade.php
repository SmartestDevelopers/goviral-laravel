@extends('layouts.front')

@section('content')

<h1>SEO</h1>

@endsection
